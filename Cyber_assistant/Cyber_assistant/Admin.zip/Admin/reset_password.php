<?php
$conn = mysqli_connect("localhost","root","","certificate_db");

$token = $_GET['token'] ?? '';

$q = "SELECT * FROM admin 
      WHERE reset_token='$token' 
      AND token_expiry > NOW()";

$res = mysqli_query($conn,$q);

if(mysqli_num_rows($res)==0){
    die("Invalid or Expired Token");
}
?>

<!DOCTYPE html>
<html>
<head>
<title>Reset Password</title>
</head>
<body>

<h2>Reset Password</h2>

<form method="POST">
    <input type="password" name="password" placeholder="New Password" required>
    <button name="reset">Update Password</button>
</form>

</body>
</html>

<?php
if(isset($_POST['reset'])){
    $newpass = password_hash($_POST['password'], PASSWORD_DEFAULT);

    mysqli_query($conn,
        "UPDATE admin SET password='$newpass', reset_token=NULL, token_expiry=NULL
         WHERE reset_token='$token'"
    );

    echo "Password Updated Successfully";
}
?>
