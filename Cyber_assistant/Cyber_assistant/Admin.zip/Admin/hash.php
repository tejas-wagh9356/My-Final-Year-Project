<?php
echo password_hash("Pass@123", PASSWORD_DEFAULT);
?>
